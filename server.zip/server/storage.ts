import {
  users,
  energyData,
  safetyAlerts,
  powerLines,
  poles,
  weatherData,
  systemSettings,
  gridOperators,
  type User,
  type UpsertUser,
  type EnergyData,
  type InsertEnergyData,
  type SafetyAlert,
  type InsertSafetyAlert,
  type PowerLine,
  type InsertPowerLine,
  type Pole,
  type InsertPole,
  type WeatherData,
  type InsertWeatherData,
  type SystemSetting,
  type GridOperator,
  type InsertGridOperator,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, gte } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Energy data operations
  getLatestEnergyData(): Promise<EnergyData | undefined>;
  insertEnergyData(data: InsertEnergyData): Promise<EnergyData>;
  getEnergyDataHistory(hours: number): Promise<EnergyData[]>;

  // Safety alerts operations
  getActiveAlerts(): Promise<SafetyAlert[]>;
  insertSafetyAlert(alert: InsertSafetyAlert): Promise<SafetyAlert>;
  resolveAlert(id: string): Promise<SafetyAlert | undefined>;

  // Power lines operations
  getAllPowerLines(): Promise<PowerLine[]>;
  updatePowerLineStatus(id: string, status: string, load: number): Promise<PowerLine | undefined>;

  // Poles operations
  getAllPoles(): Promise<Pole[]>;
  updatePoleStatus(id: string, status: string): Promise<Pole | undefined>;

  // Weather data operations
  getLatestWeatherData(): Promise<WeatherData | undefined>;
  insertWeatherData(data: InsertWeatherData): Promise<WeatherData>;

  // System settings operations
  getSystemSetting(key: string): Promise<SystemSetting | undefined>;
  updateSystemSetting(key: string, value: string): Promise<SystemSetting>;

  // Grid operators operations
  getAllGridOperators(): Promise<GridOperator[]>;
  insertGridOperator(operator: InsertGridOperator): Promise<GridOperator>;
  updateGridOperator(id: string, updates: Partial<InsertGridOperator>): Promise<GridOperator | undefined>;
  deleteGridOperator(id: string): Promise<void>;
  getActiveGridOperators(): Promise<GridOperator[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async getLatestEnergyData(): Promise<EnergyData | undefined> {
    const [data] = await db
      .select()
      .from(energyData)
      .orderBy(desc(energyData.timestamp))
      .limit(1);
    return data;
  }

  async insertEnergyData(data: InsertEnergyData): Promise<EnergyData> {
    const [result] = await db.insert(energyData).values(data).returning();
    return result;
  }

  async getEnergyDataHistory(hours: number): Promise<EnergyData[]> {
    const since = new Date(Date.now() - hours * 60 * 60 * 1000);
    return await db
      .select()
      .from(energyData)
      .where(gte(energyData.timestamp, since))
      .orderBy(desc(energyData.timestamp));
  }

  async getActiveAlerts(): Promise<SafetyAlert[]> {
    return await db
      .select()
      .from(safetyAlerts)
      .where(eq(safetyAlerts.status, 'active'))
      .orderBy(desc(safetyAlerts.createdAt));
  }

  async insertSafetyAlert(alert: InsertSafetyAlert): Promise<SafetyAlert> {
    const [result] = await db.insert(safetyAlerts).values(alert).returning();
    return result;
  }

  async resolveAlert(id: string): Promise<SafetyAlert | undefined> {
    const [result] = await db
      .update(safetyAlerts)
      .set({ status: 'resolved', resolvedAt: new Date() })
      .where(eq(safetyAlerts.id, id))
      .returning();
    return result;
  }

  async getAllPowerLines(): Promise<PowerLine[]> {
    return await db.select().from(powerLines).orderBy(powerLines.name);
  }

  async updatePowerLineStatus(id: string, status: string, load: number): Promise<PowerLine | undefined> {
    const [result] = await db
      .update(powerLines)
      .set({ status, loadPercentage: load, lastCheck: new Date() })
      .where(eq(powerLines.id, id))
      .returning();
    return result;
  }

  async getAllPoles(): Promise<Pole[]> {
    return await db.select().from(poles).orderBy(poles.poleId);
  }

  async updatePoleStatus(id: string, status: string): Promise<Pole | undefined> {
    const [result] = await db
      .update(poles)
      .set({ status, lastInspection: new Date() })
      .where(eq(poles.id, id))
      .returning();
    return result;
  }

  async getLatestWeatherData(): Promise<WeatherData | undefined> {
    const [data] = await db
      .select()
      .from(weatherData)
      .orderBy(desc(weatherData.timestamp))
      .limit(1);
    return data;
  }

  async insertWeatherData(data: InsertWeatherData): Promise<WeatherData> {
    const [result] = await db.insert(weatherData).values(data).returning();
    return result;
  }

  async getSystemSetting(key: string): Promise<SystemSetting | undefined> {
    const [setting] = await db
      .select()
      .from(systemSettings)
      .where(eq(systemSettings.key, key));
    return setting;
  }

  async updateSystemSetting(key: string, value: string): Promise<SystemSetting> {
    const [result] = await db
      .insert(systemSettings)
      .values({ key, value })
      .onConflictDoUpdate({
        target: systemSettings.key,
        set: { value, updatedAt: new Date() },
      })
      .returning();
    return result;
  }

  async getAllGridOperators(): Promise<GridOperator[]> {
    return await db.select().from(gridOperators).orderBy(gridOperators.name);
  }

  async insertGridOperator(operator: InsertGridOperator): Promise<GridOperator> {
    const [result] = await db.insert(gridOperators).values(operator).returning();
    return result;
  }

  async updateGridOperator(id: string, updates: Partial<InsertGridOperator>): Promise<GridOperator | undefined> {
    const [result] = await db
      .update(gridOperators)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(gridOperators.id, id))
      .returning();
    return result;
  }

  async deleteGridOperator(id: string): Promise<void> {
    await db.delete(gridOperators).where(eq(gridOperators.id, id));
  }

  async getActiveGridOperators(): Promise<GridOperator[]> {
    return await db
      .select()
      .from(gridOperators)
      .where(eq(gridOperators.isActive, true))
      .orderBy(gridOperators.name);
  }
}

export const storage = new DatabaseStorage();
