import type { Express, Request } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import {
  insertEnergyDataSchema,
  insertSafetyAlertSchema,
  insertWeatherDataSchema,
  insertGridOperatorSchema,
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Energy data routes
  app.get('/api/energy/latest', isAuthenticated, async (req, res) => {
    try {
      const data = await storage.getLatestEnergyData();
      res.json(data);
    } catch (error) {
      console.error("Error fetching energy data:", error);
      res.status(500).json({ message: "Failed to fetch energy data" });
    }
  });

  app.get('/api/energy/history/:hours', isAuthenticated, async (req, res) => {
    try {
      const hours = parseInt(req.params.hours) || 24;
      const data = await storage.getEnergyDataHistory(hours);
      res.json(data);
    } catch (error) {
      console.error("Error fetching energy history:", error);
      res.status(500).json({ message: "Failed to fetch energy history" });
    }
  });

  app.post('/api/energy', isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertEnergyDataSchema.parse(req.body);
      const result = await storage.insertEnergyData(validatedData);
      res.json(result);
    } catch (error) {
      console.error("Error inserting energy data:", error);
      res.status(400).json({ message: "Invalid energy data" });
    }
  });

  // Safety alerts routes
  app.get('/api/alerts', isAuthenticated, async (req, res) => {
    try {
      const alerts = await storage.getActiveAlerts();
      res.json(alerts);
    } catch (error) {
      console.error("Error fetching alerts:", error);
      res.status(500).json({ message: "Failed to fetch alerts" });
    }
  });

  app.post('/api/alerts', isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertSafetyAlertSchema.parse(req.body);
      const result = await storage.insertSafetyAlert(validatedData);
      res.json(result);
    } catch (error) {
      console.error("Error creating alert:", error);
      res.status(400).json({ message: "Invalid alert data" });
    }
  });

  app.patch('/api/alerts/:id/resolve', isAuthenticated, async (req, res) => {
    try {
      const result = await storage.resolveAlert(req.params.id);
      res.json(result);
    } catch (error) {
      console.error("Error resolving alert:", error);
      res.status(500).json({ message: "Failed to resolve alert" });
    }
  });

  // Power lines routes
  app.get('/api/powerlines', isAuthenticated, async (req, res) => {
    try {
      const lines = await storage.getAllPowerLines();
      res.json(lines);
    } catch (error) {
      console.error("Error fetching power lines:", error);
      res.status(500).json({ message: "Failed to fetch power lines" });
    }
  });

  app.patch('/api/powerlines/:id', isAuthenticated, async (req, res) => {
    try {
      const { status, loadPercentage } = req.body;
      const result = await storage.updatePowerLineStatus(req.params.id, status, loadPercentage);
      res.json(result);
    } catch (error) {
      console.error("Error updating power line:", error);
      res.status(500).json({ message: "Failed to update power line" });
    }
  });

  // Poles routes
  app.get('/api/poles', isAuthenticated, async (req, res) => {
    try {
      const poles = await storage.getAllPoles();
      res.json(poles);
    } catch (error) {
      console.error("Error fetching poles:", error);
      res.status(500).json({ message: "Failed to fetch poles" });
    }
  });

  app.patch('/api/poles/:id', isAuthenticated, async (req, res) => {
    try {
      const { status } = req.body;
      const result = await storage.updatePoleStatus(req.params.id, status);
      res.json(result);
    } catch (error) {
      console.error("Error updating pole:", error);
      res.status(500).json({ message: "Failed to update pole" });
    }
  });

  // Weather data routes
  app.get('/api/weather/latest', isAuthenticated, async (req, res) => {
    try {
      const data = await storage.getLatestWeatherData();
      res.json(data);
    } catch (error) {
      console.error("Error fetching weather data:", error);
      res.status(500).json({ message: "Failed to fetch weather data" });
    }
  });

  app.post('/api/weather', isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertWeatherDataSchema.parse(req.body);
      const result = await storage.insertWeatherData(validatedData);
      res.json(result);
    } catch (error) {
      console.error("Error inserting weather data:", error);
      res.status(400).json({ message: "Invalid weather data" });
    }
  });

  // Emergency SOS endpoint
  app.post('/api/emergency/sos', isAuthenticated, async (req, res) => {
    try {
      const userId = (req as any).user?.claims?.sub;
      const user = await storage.getUser(userId);
      
      const sosAlert = {
        type: 'critical',
        title: 'EMERGENCY SOS ACTIVATED',
        description: `Emergency SOS activated by ${user?.firstName} ${user?.lastName} (${user?.email})`,
        location: req.body.location || 'Unknown location',
        coordinates: req.body.coordinates || '',
      };

      const result = await storage.insertSafetyAlert(sosAlert);
      
      // Broadcast to all connected WebSocket clients
      wss.clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify({
            type: 'emergency_sos',
            data: result
          }));
        }
      });

      res.json(result);
    } catch (error) {
      console.error("Error activating SOS:", error);
      res.status(500).json({ message: "Failed to activate SOS" });
    }
  });

  // System control endpoints
  app.post('/api/system/shutdown', isAuthenticated, async (req, res) => {
    try {
      const userId = (req as any).user?.claims?.sub;
      const user = await storage.getUser(userId);
      
      const shutdownAlert = {
        type: 'critical',
        title: 'SYSTEM SHUTDOWN INITIATED',
        description: `Emergency shutdown initiated by ${user?.firstName} ${user?.lastName}`,
        location: 'System Control Center',
        coordinates: '',
      };

      await storage.insertSafetyAlert(shutdownAlert);
      res.json({ message: "Shutdown sequence initiated" });
    } catch (error) {
      console.error("Error initiating shutdown:", error);
      res.status(500).json({ message: "Failed to initiate shutdown" });
    }
  });

  app.post('/api/system/maintenance', isAuthenticated, async (req, res) => {
    try {
      await storage.updateSystemSetting('maintenance_mode', 'enabled');
      res.json({ message: "Maintenance mode enabled" });
    } catch (error) {
      console.error("Error enabling maintenance mode:", error);
      res.status(500).json({ message: "Failed to enable maintenance mode" });
    }
  });

  app.post('/api/system/test-alert', isAuthenticated, async (req, res) => {
    try {
      const testAlert = {
        type: 'warning',
        title: 'ALERT SYSTEM TEST',
        description: 'This is a test of the emergency alert system. All systems are functioning normally.',
        location: 'Control Center',
        coordinates: '',
      };

      const result = await storage.insertSafetyAlert(testAlert);
      
      // Broadcast test alert
      wss.clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify({
            type: 'test_alert',
            data: result
          }));
        }
      });

      res.json(result);
    } catch (error) {
      console.error("Error sending test alert:", error);
      res.status(500).json({ message: "Failed to send test alert" });
    }
  });

  // Grid operators routes
  app.get('/api/grid-operators', isAuthenticated, async (req, res) => {
    try {
      const operators = await storage.getAllGridOperators();
      res.json(operators);
    } catch (error) {
      console.error("Error fetching grid operators:", error);
      res.status(500).json({ message: "Failed to fetch grid operators" });
    }
  });

  app.post('/api/grid-operators', isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertGridOperatorSchema.parse(req.body);
      const result = await storage.insertGridOperator(validatedData);
      res.json(result);
    } catch (error) {
      console.error("Error creating grid operator:", error);
      res.status(400).json({ message: "Invalid grid operator data" });
    }
  });

  app.put('/api/grid-operators/:id', isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertGridOperatorSchema.partial().parse(req.body);
      const result = await storage.updateGridOperator(req.params.id, validatedData);
      if (!result) {
        return res.status(404).json({ message: "Grid operator not found" });
      }
      res.json(result);
    } catch (error) {
      console.error("Error updating grid operator:", error);
      res.status(400).json({ message: "Invalid grid operator data" });
    }
  });

  app.delete('/api/grid-operators/:id', isAuthenticated, async (req, res) => {
    try {
      await storage.deleteGridOperator(req.params.id);
      res.json({ message: "Grid operator deleted successfully" });
    } catch (error) {
      console.error("Error deleting grid operator:", error);
      res.status(500).json({ message: "Failed to delete grid operator" });
    }
  });

  app.get('/api/grid-operators/active', isAuthenticated, async (req, res) => {
    try {
      const operators = await storage.getActiveGridOperators();
      res.json(operators);
    } catch (error) {
      console.error("Error fetching active grid operators:", error);
      res.status(500).json({ message: "Failed to fetch active grid operators" });
    }
  });

  const httpServer = createServer(app);

  // WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws) => {
    console.log('Client connected to WebSocket');

    ws.on('close', () => {
      console.log('Client disconnected from WebSocket');
    });

    // Send initial data
    ws.send(JSON.stringify({
      type: 'connection',
      message: 'Connected to Energy Monitoring System'
    }));
  });

  // Simulate real-time data updates (in production, this would come from IoT devices)
  setInterval(async () => {
    try {
      const mockEnergyData = {
        solarGeneration: (Math.random() * 10 + 20).toFixed(1),
        batteryCharge: Math.floor(Math.random() * 20 + 80),
        gridEfficiency: (Math.random() * 5 + 92).toFixed(1),
        voltage: (Math.random() * 10 + 235).toFixed(1),
        current: (Math.random() * 5 + 10).toFixed(1),
        frequency: (Math.random() * 0.4 + 49.8).toFixed(1),
        energyGenerated: (Math.random() * 50 + 450).toFixed(1),
        energyConsumed: (Math.random() * 40 + 320).toFixed(1),
        energyStored: (Math.random() * 20 + 140).toFixed(1),
      };

      await storage.insertEnergyData(mockEnergyData);

      // Broadcast to all connected clients
      wss.clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify({
            type: 'energy_update',
            data: mockEnergyData
          }));
        }
      });
    } catch (error) {
      console.error('Error sending real-time update:', error);
    }
  }, 5000); // Update every 5 seconds

  return httpServer;
}
