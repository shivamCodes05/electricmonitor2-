import { sql } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  decimal,
  integer,
  text,
  boolean,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: varchar("role").default('official'),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Energy generation data
export const energyData = pgTable("energy_data", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  timestamp: timestamp("timestamp").defaultNow(),
  solarGeneration: decimal("solar_generation", { precision: 10, scale: 2 }),
  batteryCharge: integer("battery_charge"),
  gridEfficiency: decimal("grid_efficiency", { precision: 5, scale: 2 }),
  voltage: decimal("voltage", { precision: 6, scale: 2 }),
  current: decimal("current", { precision: 6, scale: 2 }),
  frequency: decimal("frequency", { precision: 4, scale: 1 }),
  energyGenerated: decimal("energy_generated", { precision: 10, scale: 2 }),
  energyConsumed: decimal("energy_consumed", { precision: 10, scale: 2 }),
  energyStored: decimal("energy_stored", { precision: 10, scale: 2 }),
});

// Safety alerts
export const safetyAlerts = pgTable("safety_alerts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  type: varchar("type").notNull(), // 'warning', 'critical', 'normal'
  title: text("title").notNull(),
  description: text("description"),
  location: text("location"),
  coordinates: text("coordinates"),
  status: varchar("status").default('active'), // 'active', 'resolved'
  createdAt: timestamp("created_at").defaultNow(),
  resolvedAt: timestamp("resolved_at"),
});

// Power lines monitoring
export const powerLines = pgTable("power_lines", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  location: text("location").notNull(),
  status: varchar("status").default('active'), // 'active', 'caution', 'fault'
  loadPercentage: integer("load_percentage").default(0),
  lastCheck: timestamp("last_check").defaultNow(),
});

// Infrastructure poles
export const poles = pgTable("poles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  poleId: varchar("pole_id").unique().notNull(),
  coordinates: text("coordinates").notNull(),
  status: varchar("status").default('stable'), // 'stable', 'inspection', 'maintenance'
  lastInspection: timestamp("last_inspection").defaultNow(),
});

// Weather data
export const weatherData = pgTable("weather_data", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  timestamp: timestamp("timestamp").defaultNow(),
  temperature: decimal("temperature", { precision: 4, scale: 1 }),
  condition: varchar("condition"),
  visibility: decimal("visibility", { precision: 4, scale: 1 }),
  windSpeed: decimal("wind_speed", { precision: 4, scale: 1 }),
  humidity: integer("humidity"),
  feelsLike: decimal("feels_like", { precision: 4, scale: 1 }),
  location: text("location"),
});

// System settings
export const systemSettings = pgTable("system_settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  key: varchar("key").unique().notNull(),
  value: text("value"),
  description: text("description"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Grid operator contacts
export const gridOperators = pgTable("grid_operators", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  phoneNumber: varchar("phone_number").notNull(),
  email: varchar("email"),
  role: varchar("role").default('operator'), // 'operator', 'supervisor', 'manager'
  zone: varchar("zone"), // Coverage zone or area
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

export const insertEnergyDataSchema = createInsertSchema(energyData).omit({
  id: true,
  timestamp: true,
});

export const insertSafetyAlertSchema = createInsertSchema(safetyAlerts).omit({
  id: true,
  createdAt: true,
});

export const insertPowerLineSchema = createInsertSchema(powerLines).omit({
  id: true,
  lastCheck: true,
});

export const insertPoleSchema = createInsertSchema(poles).omit({
  id: true,
  lastInspection: true,
});

export const insertWeatherDataSchema = createInsertSchema(weatherData).omit({
  id: true,
  timestamp: true,
});

export const insertGridOperatorSchema = createInsertSchema(gridOperators).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertEnergyData = z.infer<typeof insertEnergyDataSchema>;
export type InsertSafetyAlert = z.infer<typeof insertSafetyAlertSchema>;
export type InsertPowerLine = z.infer<typeof insertPowerLineSchema>;
export type InsertPole = z.infer<typeof insertPoleSchema>;
export type InsertWeatherData = z.infer<typeof insertWeatherDataSchema>;
export type InsertGridOperator = z.infer<typeof insertGridOperatorSchema>;

export type EnergyData = typeof energyData.$inferSelect;
export type SafetyAlert = typeof safetyAlerts.$inferSelect;
export type PowerLine = typeof powerLines.$inferSelect;
export type Pole = typeof poles.$inferSelect;
export type WeatherData = typeof weatherData.$inferSelect;
export type SystemSetting = typeof systemSettings.$inferSelect;
export type GridOperator = typeof gridOperators.$inferSelect;
