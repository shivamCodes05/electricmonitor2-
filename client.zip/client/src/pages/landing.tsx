import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Zap, Shield } from "lucide-react";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary to-secondary p-4">
      <div className="w-full max-w-md">
        {/* Energy monitoring system logo and branding */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-primary-foreground rounded-full mb-4">
            <Zap className="text-primary text-2xl" />
          </div>
          <h1 className="text-3xl font-bold text-primary-foreground mb-2">Energy Monitor</h1>
          <p className="text-primary-foreground/80">Official Access Portal</p>
        </div>
        
        {/* Authentication card */}
        <Card className="shadow-2xl">
          <CardContent className="p-8">
            <h2 className="text-2xl font-semibold text-card-foreground mb-6 text-center">Administrative Login</h2>
            
            <div className="space-y-6">
              <p className="text-center text-muted-foreground">
                Access the Energy Monitoring Dashboard with your official credentials.
              </p>
              
              <Button 
                onClick={handleLogin}
                className="w-full"
                size="lg"
                data-testid="button-login"
              >
                <Zap className="mr-2 h-4 w-4" />
                Login to Dashboard
              </Button>
              
              <div className="text-center">
                <p className="text-sm text-muted-foreground flex items-center justify-center">
                  <Shield className="mr-1 h-4 w-4" />
                  Authorized personnel only
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
