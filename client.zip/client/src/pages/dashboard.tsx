import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { isUnauthorizedError } from '@/lib/authUtils';
import Sidebar from '@/components/layout/sidebar';
import EnergyMetrics from '@/components/dashboard/energy-metrics';
import PowerChart from '@/components/dashboard/power-chart';
import ElectricalGauges from '@/components/dashboard/electrical-gauges';
import EnergyStats from '@/components/dashboard/energy-stats';
import AlertPanel from '@/components/safety/alert-panel';
import LineStatus from '@/components/safety/line-status';
import WeatherDisplay from '@/components/weather/weather-display';
import SystemControls from '@/components/admin/system-controls';
import { Button } from '@/components/ui/button';
import { AlertTriangle } from 'lucide-react';

export default function Dashboard() {
  const { isAuthenticated, isLoading, user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [alertStatus, setAlertStatus] = useState<'normal' | 'warning' | 'critical'>('normal');

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const handleEmergencySOS = async () => {
    try {
      const response = await fetch('/api/emergency/sos', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          location: 'Control Center',
          coordinates: '37.7749° N, 122.4194° W',
        }),
        credentials: 'include',
      });

      if (!response.ok) {
        throw new Error('Failed to activate SOS');
      }

      setAlertStatus('critical');
      toast({
        title: "Emergency SOS Activated",
        description: "Emergency services have been notified. Help is on the way.",
        variant: "destructive",
      });
    } catch (error: any) {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to activate emergency SOS. Please try again.",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null; // Will redirect via useEffect
  }

  const getStatusDisplay = () => {
    switch (alertStatus) {
      case 'critical':
        return { text: 'CRITICAL ALERT', color: 'bg-destructive text-destructive-foreground', pulse: 'animate-pulse' };
      case 'warning':
        return { text: 'WARNING ACTIVE', color: 'bg-accent text-accent-foreground', pulse: 'animate-pulse' };
      default:
        return { text: 'System Normal', color: 'bg-secondary text-secondary-foreground', pulse: '' };
    }
  };

  const statusDisplay = getStatusDisplay();

  return (
    <div className="min-h-screen bg-background">
      <Sidebar activeTab={activeTab} onTabChange={setActiveTab} />
      
      {/* Main Content Area */}
      <main className="md:ml-64 p-6">
        {/* Header */}
        <header className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-card-foreground">Energy Monitoring Dashboard</h1>
            <p className="text-muted-foreground mt-1">Real-time renewable energy system monitoring</p>
          </div>
          
          {/* Emergency Alert Banner */}
          <div className="flex items-center space-x-4">
            <div className={`px-4 py-2 rounded-lg flex items-center ${statusDisplay.color}`}>
              <div className={`w-3 h-3 bg-current rounded-full mr-2 ${statusDisplay.pulse}`}></div>
              <span className="font-medium" data-testid="text-system-status">{statusDisplay.text}</span>
            </div>
            
            <Button 
              onClick={handleEmergencySOS}
              variant="destructive"
              size="lg"
              data-testid="button-emergency-sos"
            >
              <AlertTriangle className="mr-2 h-4 w-4" />
              Emergency SOS
            </Button>
          </div>
        </header>

        {/* Tab Content */}
        {activeTab === 'dashboard' && (
          <div className="space-y-8">
            <EnergyMetrics />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <PowerChart />
              <ElectricalGauges />
            </div>
            <EnergyStats />
          </div>
        )}

        {activeTab === 'safety' && (
          <div className="space-y-8">
            <div>
              <h2 className="text-2xl font-bold text-card-foreground mb-2">Safety Monitoring System</h2>
              <p className="text-muted-foreground">Real-time monitoring of grid infrastructure and safety systems</p>
            </div>
            <AlertPanel onAlertStatusChange={setAlertStatus} />
            <LineStatus />
          </div>
        )}

        {activeTab === 'weather' && (
          <div className="space-y-8">
            <div>
              <h2 className="text-2xl font-bold text-card-foreground mb-2">Weather & Environmental Monitoring</h2>
              <p className="text-muted-foreground">Live weather conditions and environmental factors affecting energy generation</p>
            </div>
            <WeatherDisplay />
          </div>
        )}

        {activeTab === 'admin' && (
          <div className="space-y-8">
            <div>
              <h2 className="text-2xl font-bold text-card-foreground mb-2">Administrative Controls</h2>
              <p className="text-muted-foreground">System configuration and administrative functions</p>
            </div>
            <SystemControls user={user} />
          </div>
        )}
      </main>
    </div>
  );
}
