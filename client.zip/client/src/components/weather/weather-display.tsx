import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Sun, 
  Eye, 
  Wind, 
  Droplets, 
  Thermometer, 
  CheckCircle, 
  AlertTriangle, 
  Cloud,
  Zap
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { isUnauthorizedError } from '@/lib/authUtils';
import LocationPicker from './location-picker';

interface WeatherData {
  id: string;
  temperature: string;
  condition: string;
  visibility: string;
  windSpeed: string;
  humidity: number;
  feelsLike: string;
  location: string;
  timestamp: string;
}

export default function WeatherDisplay() {
  const [weatherData, setWeatherData] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    fetchWeatherData();
    
    // Fetch weather data every 10 minutes
    const interval = setInterval(fetchWeatherData, 10 * 60 * 1000);
    
    return () => clearInterval(interval);
  }, []);

  const fetchWeatherData = async () => {
    try {
      const response = await fetch('/api/weather/latest', { credentials: 'include' });
      if (response.ok) {
        const data = await response.json();
        if (data) {
          setWeatherData(data);
        } else {
          // If no weather data exists, create some sample data
          await createSampleWeatherData();
        }
      }
    } catch (error: any) {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      console.error('Error fetching weather data:', error);
    } finally {
      setLoading(false);
    }
  };

  const createSampleWeatherData = async () => {
    try {
      const sampleData = {
        temperature: '24.0',
        condition: 'Sunny',
        visibility: '10.0',
        windSpeed: '12.0',
        humidity: 65,
        feelsLike: '26.0',
        location: 'San Francisco, CA'
      };

      const response = await fetch('/api/weather', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(sampleData),
        credentials: 'include',
      });

      if (response.ok) {
        const createdData = await response.json();
        setWeatherData(createdData);
      }
    } catch (error) {
      console.error('Error creating sample weather data:', error);
    }
  };

  const getWeatherIcon = (condition: string) => {
    const cond = condition.toLowerCase();
    if (cond.includes('sun')) return Sun;
    if (cond.includes('cloud')) return Cloud;
    if (cond.includes('rain')) return Droplets;
    if (cond.includes('wind')) return Wind;
    return Sun; // default
  };

  const getGenerationEfficiency = (condition: string, visibility: string) => {
    const cond = condition.toLowerCase();
    const vis = parseFloat(visibility);
    
    if (cond.includes('sun') && vis >= 8) return { efficiency: 95, status: 'optimal' };
    if (cond.includes('cloud') || vis < 8) return { efficiency: 75, status: 'reduced' };
    if (cond.includes('rain')) return { efficiency: 45, status: 'low' };
    
    return { efficiency: 85, status: 'good' };
  };

  const weatherConditions = weatherData ? [
    {
      label: 'Visibility',
      value: `${weatherData.visibility} km`,
      icon: Eye,
      testId: 'weather-visibility'
    },
    {
      label: 'Wind Speed',
      value: `${weatherData.windSpeed} km/h`,
      icon: Wind,
      testId: 'weather-wind'
    },
    {
      label: 'Humidity',
      value: `${weatherData.humidity}%`,
      icon: Droplets,
      testId: 'weather-humidity'
    },
    {
      label: 'Feels Like',
      value: `${weatherData.feelsLike}°C`,
      icon: Thermometer,
      testId: 'weather-feels-like'
    }
  ] : [];

  if (loading) {
    return (
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-center h-64">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          </CardContent>
        </Card>
        <Card className="shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-center h-64">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!weatherData) {
    return (
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="shadow-sm">
          <CardContent className="p-6">
            <div className="text-center text-muted-foreground py-8">
              <Cloud className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p>No weather data available</p>
            </div>
          </CardContent>
        </Card>
        <Card className="shadow-sm">
          <CardContent className="p-6">
            <div className="text-center text-muted-foreground py-8">
              <AlertTriangle className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p>Weather alerts unavailable</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const WeatherIcon = getWeatherIcon(weatherData.condition);
  const generationForecast = getGenerationEfficiency(weatherData.condition, weatherData.visibility);

  return (
    <div className="space-y-6">
      {/* Location Management */}
      <LocationPicker />
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Current Weather */}
        <Card className="shadow-sm" data-testid="card-weather-current">
        <CardHeader>
          <CardTitle className="text-lg font-semibold">Current Weather Conditions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center mb-6">
            <div className="w-24 h-24 mx-auto bg-accent/20 rounded-full flex items-center justify-center mb-4">
              <WeatherIcon className="text-accent h-12 w-12" />
            </div>
            <div className="text-4xl font-bold text-card-foreground" data-testid="text-temperature">
              {weatherData.temperature}°C
            </div>
            <div className="text-lg text-muted-foreground" data-testid="text-condition">
              {weatherData.condition}
            </div>
            <div className="text-sm text-muted-foreground" data-testid="text-location">
              {weatherData.location}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {weatherConditions.map((item) => {
              const Icon = item.icon;
              return (
                <div key={item.label} className="text-center p-4 bg-muted/30 rounded-lg" data-testid={item.testId}>
                  <Icon className="text-primary mb-2 h-5 w-5 mx-auto" />
                  <div className="text-sm text-muted-foreground">{item.label}</div>
                  <div className="font-semibold text-card-foreground" data-testid={`value-${item.testId}`}>
                    {item.value}
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Weather Alerts & Impact */}
      <Card className="shadow-sm" data-testid="card-weather-alerts">
        <CardHeader>
          <CardTitle className="text-lg font-semibold">Weather Alerts & Impact</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Optimal Solar Conditions */}
            <div className="p-4 bg-secondary/10 border border-secondary/20 rounded-lg">
              <div className="flex items-center mb-2">
                <CheckCircle className="text-secondary mr-2 h-4 w-4" />
                <span className="font-medium text-card-foreground">Optimal Solar Conditions</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Clear skies with high solar irradiance. Peak generation expected between 11 AM - 3 PM.
              </p>
            </div>

            {/* Wind Advisory */}
            <div className="p-4 bg-accent/10 border border-accent/20 rounded-lg">
              <div className="flex items-center mb-2">
                <AlertTriangle className="text-accent mr-2 h-4 w-4" />
                <span className="font-medium text-card-foreground">Wind Advisory</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Moderate winds detected. Monitor transmission lines for any oscillations or stability issues.
              </p>
            </div>

            {/* No Severe Weather */}
            <div className="p-4 bg-muted/30 border border-border rounded-lg">
              <div className="flex items-center mb-2">
                <Cloud className="text-muted-foreground mr-2 h-4 w-4" />
                <span className="font-medium text-card-foreground">No Severe Weather</span>
              </div>
              <p className="text-sm text-muted-foreground">
                No severe weather alerts for the next 24 hours. Normal operations expected.
              </p>
            </div>
          </div>

          {/* Generation Forecast */}
          <div className="mt-6 p-4 bg-primary/10 border border-primary/20 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-medium text-card-foreground flex items-center">
                <Zap className="mr-2 h-4 w-4" />
                Generation Forecast
              </h4>
              <Badge variant="outline" data-testid="badge-generation-efficiency">
                {generationForecast.efficiency}% efficiency
              </Badge>
            </div>
            <div className="text-sm text-muted-foreground">
              Based on current weather patterns, expect {' '}
              <span className="font-semibold text-primary">
                {generationForecast.efficiency}% efficiency
              </span>{' '}
              for solar generation today.
            </div>
          </div>
        </CardContent>
      </Card>
      </div>
    </div>
  );
}
