import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { 
  MapPin, 
  Navigation, 
  Crosshair, 
  Plus, 
  Edit,
  Trash2,
  Globe
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { isUnauthorizedError } from '@/lib/authUtils';

interface Location {
  id: string;
  name: string;
  latitude: number;
  longitude: number;
  isActive: boolean;
  type: 'current' | 'remote' | 'monitoring';
}

export default function LocationPicker() {
  const { toast } = useToast();
  const [locations, setLocations] = useState<Location[]>([]);
  const [currentLocation, setCurrentLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingLocation, setEditingLocation] = useState<Location | null>(null);
  const [isGettingLocation, setIsGettingLocation] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    latitude: '',
    longitude: '',
    type: 'remote' as 'current' | 'remote' | 'monitoring'
  });

  useEffect(() => {
    fetchLocations();
    getCurrentLocation();
  }, []);

  const fetchLocations = async () => {
    try {
      // For now, use local storage to manage locations
      // In production, this would call an API endpoint
      const savedLocations = localStorage.getItem('energy-monitor-locations');
      if (savedLocations) {
        setLocations(JSON.parse(savedLocations));
      } else {
        // Initialize with default locations
        const defaultLocations: Location[] = [
          {
            id: '1',
            name: 'Main Control Center',
            latitude: 37.7749,
            longitude: -122.4194,
            isActive: true,
            type: 'current'
          },
          {
            id: '2',
            name: 'Remote Station Alpha',
            latitude: 37.7849,
            longitude: -122.4094,
            isActive: true,
            type: 'remote'
          },
          {
            id: '3',
            name: 'Monitoring Point Beta',
            latitude: 37.7649,
            longitude: -122.4294,
            isActive: true,
            type: 'monitoring'
          }
        ];
        setLocations(defaultLocations);
        localStorage.setItem('energy-monitor-locations', JSON.stringify(defaultLocations));
      }
    } catch (error) {
      console.error('Error fetching locations:', error);
    }
  };

  const getCurrentLocation = () => {
    if (navigator.geolocation) {
      setIsGettingLocation(true);
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const coords = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude
          };
          setCurrentLocation(coords);
          setIsGettingLocation(false);
          
          toast({
            title: "Location Found",
            description: `Current location: ${coords.latitude.toFixed(4)}, ${coords.longitude.toFixed(4)}`,
          });
        },
        (error) => {
          console.error('Error getting location:', error);
          setIsGettingLocation(false);
          toast({
            title: "Location Error",
            description: "Could not retrieve current location. Please enter coordinates manually.",
            variant: "destructive",
          });
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 300000 }
      );
    } else {
      toast({
        title: "Geolocation Not Supported",
        description: "Your browser does not support geolocation. Please enter coordinates manually.",
        variant: "destructive",
      });
    }
  };

  const handleSubmitLocation = (e: React.FormEvent) => {
    e.preventDefault();
    
    const latitude = parseFloat(formData.latitude);
    const longitude = parseFloat(formData.longitude);
    
    if (isNaN(latitude) || isNaN(longitude)) {
      toast({
        title: "Invalid Coordinates",
        description: "Please enter valid latitude and longitude values.",
        variant: "destructive",
      });
      return;
    }

    const newLocation: Location = {
      id: editingLocation ? editingLocation.id : Date.now().toString(),
      name: formData.name,
      latitude,
      longitude,
      isActive: true,
      type: formData.type
    };

    let updatedLocations;
    if (editingLocation) {
      updatedLocations = locations.map(loc => loc.id === editingLocation.id ? newLocation : loc);
    } else {
      updatedLocations = [...locations, newLocation];
    }

    setLocations(updatedLocations);
    localStorage.setItem('energy-monitor-locations', JSON.stringify(updatedLocations));

    toast({
      title: editingLocation ? "Location Updated" : "Location Added",
      description: `${formData.name} has been ${editingLocation ? 'updated' : 'added'} successfully.`,
    });

    setIsAddDialogOpen(false);
    setEditingLocation(null);
    setFormData({ name: '', latitude: '', longitude: '', type: 'remote' });
  };

  const handleEditLocation = (location: Location) => {
    setEditingLocation(location);
    setFormData({
      name: location.name,
      latitude: location.latitude.toString(),
      longitude: location.longitude.toString(),
      type: location.type
    });
    setIsAddDialogOpen(true);
  };

  const handleDeleteLocation = (id: string) => {
    if (!confirm('Are you sure you want to delete this location?')) return;
    
    const updatedLocations = locations.filter(loc => loc.id !== id);
    setLocations(updatedLocations);
    localStorage.setItem('energy-monitor-locations', JSON.stringify(updatedLocations));
    
    toast({
      title: "Location Deleted",
      description: "Location has been removed successfully.",
    });
  };

  const useCurrentLocation = () => {
    if (currentLocation) {
      setFormData({
        ...formData,
        latitude: currentLocation.latitude.toString(),
        longitude: currentLocation.longitude.toString()
      });
    }
  };

  const getLocationTypeColor = (type: string) => {
    switch (type) {
      case 'current':
        return 'bg-primary text-primary-foreground';
      case 'remote':
        return 'bg-secondary text-secondary-foreground';
      case 'monitoring':
        return 'bg-accent text-accent-foreground';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <Card className="shadow-sm" data-testid="card-location-picker">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold flex items-center">
            <MapPin className="mr-2 h-5 w-5" />
            Current Location & Remote Monitoring Points
          </CardTitle>
          <div className="flex space-x-2">
            <Button 
              onClick={getCurrentLocation}
              variant="outline"
              size="sm"
              disabled={isGettingLocation}
              data-testid="button-get-location"
            >
              <Crosshair className="mr-2 h-4 w-4" />
              {isGettingLocation ? 'Getting Location...' : 'Get Current'}
            </Button>
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button onClick={() => {
                  setEditingLocation(null);
                  setFormData({ name: '', latitude: '', longitude: '', type: 'remote' });
                }} size="sm" data-testid="button-add-location">
                  <Plus className="mr-2 h-4 w-4" />
                  Add Location
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                  <DialogTitle>{editingLocation ? 'Edit' : 'Add'} Monitoring Location</DialogTitle>
                  <DialogDescription>
                    {editingLocation ? 'Update' : 'Add new'} location for energy monitoring and weather tracking.
                  </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleSubmitLocation} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="locationName">Location Name</Label>
                    <Input
                      id="locationName"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="Enter location name"
                      required
                      data-testid="input-location-name"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="latitude">Latitude</Label>
                      <Input
                        id="latitude"
                        type="number"
                        step="any"
                        value={formData.latitude}
                        onChange={(e) => setFormData({ ...formData, latitude: e.target.value })}
                        placeholder="37.7749"
                        required
                        data-testid="input-latitude"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="longitude">Longitude</Label>
                      <Input
                        id="longitude"
                        type="number"
                        step="any"
                        value={formData.longitude}
                        onChange={(e) => setFormData({ ...formData, longitude: e.target.value })}
                        placeholder="-122.4194"
                        required
                        data-testid="input-longitude"
                      />
                    </div>
                  </div>
                  {currentLocation && (
                    <Button 
                      type="button" 
                      variant="outline" 
                      size="sm" 
                      onClick={useCurrentLocation}
                      className="w-full"
                    >
                      <Navigation className="mr-2 h-4 w-4" />
                      Use Current Location ({currentLocation.latitude.toFixed(4)}, {currentLocation.longitude.toFixed(4)})
                    </Button>
                  )}
                  <div className="space-y-2">
                    <Label htmlFor="locationType">Location Type</Label>
                    <select
                      id="locationType"
                      value={formData.type}
                      onChange={(e) => setFormData({ ...formData, type: e.target.value as 'current' | 'remote' | 'monitoring' })}
                      className="w-full p-2 border border-border rounded-md"
                      data-testid="select-location-type"
                    >
                      <option value="current">Current Position</option>
                      <option value="remote">Remote Station</option>
                      <option value="monitoring">Monitoring Point</option>
                    </select>
                  </div>
                  <div className="flex justify-end space-x-2">
                    <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button type="submit" data-testid="button-save-location">
                      {editingLocation ? 'Update' : 'Add'} Location
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="text-sm text-muted-foreground mb-4">
            Manage monitoring locations for weather tracking and energy system oversight. Use GPS coordinates to precisely mark remote stations and monitoring points.
          </div>

          {currentLocation && (
            <div className="p-4 bg-primary/10 border border-primary/20 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-medium text-card-foreground flex items-center">
                  <Crosshair className="mr-2 h-4 w-4" />
                  Device Location
                </h4>
                <Badge variant="outline" className="bg-primary/20">
                  GPS Active
                </Badge>
              </div>
              <div className="text-sm text-muted-foreground">
                Current Position: {currentLocation.latitude.toFixed(6)}, {currentLocation.longitude.toFixed(6)}
              </div>
            </div>
          )}

          {locations.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Globe className="mx-auto h-12 w-12 mb-4 opacity-50" />
              <p>No monitoring locations added yet</p>
              <p className="text-sm">Add locations to track weather conditions at different sites</p>
            </div>
          ) : (
            <div className="space-y-3">
              {locations.map((location) => (
                <div
                  key={location.id}
                  className="flex items-center justify-between p-4 border border-border rounded-lg"
                  data-testid={`location-${location.id}`}
                >
                  <div className="flex items-center space-x-3">
                    <div className={`w-3 h-3 rounded-full ${location.isActive ? 'bg-secondary' : 'bg-muted'}`}></div>
                    <div>
                      <div className="font-medium text-card-foreground">{location.name}</div>
                      <div className="text-sm text-muted-foreground flex items-center">
                        <MapPin className="mr-1 h-3 w-3" />
                        {location.latitude.toFixed(4)}, {location.longitude.toFixed(4)}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge className={getLocationTypeColor(location.type)}>
                      {location.type}
                    </Badge>
                    <Button
                      onClick={() => handleEditLocation(location)}
                      variant="outline"
                      size="sm"
                      data-testid={`button-edit-location-${location.id}`}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      onClick={() => handleDeleteLocation(location.id)}
                      variant="outline"
                      size="sm"
                      data-testid={`button-delete-location-${location.id}`}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}