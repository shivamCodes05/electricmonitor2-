import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from '@/components/ui/dialog';
import { 
  Power, 
  Wrench, 
  Bell, 
  Users, 
  Shield,
  Smartphone,
  Monitor,
  Phone,
  Plus,
  Edit,
  Trash2,
  UserCheck
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { isUnauthorizedError } from '@/lib/authUtils';
import type { User, GridOperator } from '@shared/schema';

interface SystemControlsProps {
  user?: User;
}

export default function SystemControls({ user }: SystemControlsProps) {
  const { toast } = useToast();
  const [gridOperators, setGridOperators] = useState<GridOperator[]>([]);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingOperator, setEditingOperator] = useState<GridOperator | null>(null);
  const [formData, setFormData] = useState<{
    name: string;
    phoneNumber: string;
    email: string;
    role: 'operator' | 'supervisor' | 'manager';
    zone: string;
    isActive: boolean;
  }>({
    name: '',
    phoneNumber: '',
    email: '',
    role: 'operator',
    zone: '',
    isActive: true
  });

  useEffect(() => {
    fetchGridOperators();
  }, []);

  const fetchGridOperators = async () => {
    try {
      const response = await fetch('/api/grid-operators', { credentials: 'include' });
      if (response.ok) {
        const data = await response.json();
        setGridOperators(data);
      }
    } catch (error) {
      console.error('Error fetching grid operators:', error);
    }
  };

  const handleSubmitOperator = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const url = editingOperator ? `/api/grid-operators/${editingOperator.id}` : '/api/grid-operators';
      const method = editingOperator ? 'PUT' : 'POST';
      
      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        toast({
          title: editingOperator ? "Operator Updated" : "Operator Added",
          description: `${formData.name} has been ${editingOperator ? 'updated' : 'added'} successfully.`,
        });
        setIsAddDialogOpen(false);
        setEditingOperator(null);
        setFormData({ name: '', phoneNumber: '', email: '', role: 'operator', zone: '', isActive: true });
        fetchGridOperators();
      }
    } catch (error: any) {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to save operator. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleEditOperator = (operator: GridOperator) => {
    setEditingOperator(operator);
    setFormData({
      name: operator.name,
      phoneNumber: operator.phoneNumber,
      email: operator.email || '',
      role: operator.role as 'operator' | 'supervisor' | 'manager',
      zone: operator.zone || '',
      isActive: operator.isActive ?? true
    });
    setIsAddDialogOpen(true);
  };

  const handleDeleteOperator = async (id: string) => {
    if (!confirm('Are you sure you want to delete this operator?')) return;
    
    try {
      const response = await fetch(`/api/grid-operators/${id}`, {
        method: 'DELETE',
        credentials: 'include',
      });

      if (response.ok) {
        toast({
          title: "Operator Deleted",
          description: "Grid operator has been removed successfully.",
        });
        fetchGridOperators();
      }
    } catch (error: any) {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to delete operator. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleEmergencyShutdown = async () => {
    if (!confirm('Are you sure you want to initiate an emergency shutdown? This will stop all grid operations immediately.')) {
      return;
    }

    try {
      const response = await fetch('/api/system/shutdown', {
        method: 'POST',
        credentials: 'include',
      });

      if (response.ok) {
        toast({
          title: "Emergency Shutdown Initiated",
          description: "All grid operations have been shut down. Emergency protocols are now active.",
          variant: "destructive",
        });
      }
    } catch (error: any) {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to initiate shutdown. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleMaintenanceMode = async () => {
    try {
      const response = await fetch('/api/system/maintenance', {
        method: 'POST',
        credentials: 'include',
      });

      if (response.ok) {
        toast({
          title: "Maintenance Mode Enabled",
          description: "System has been put into maintenance mode. Some functions may be limited.",
        });
      }
    } catch (error: any) {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to enable maintenance mode. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleAlertSystemTest = async () => {
    try {
      const response = await fetch('/api/system/test-alert', {
        method: 'POST',
        credentials: 'include',
      });

      if (response.ok) {
        toast({
          title: "Alert System Test",
          description: "Alert system test completed. All notification channels are operational.",
        });
      }
    } catch (error: any) {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to test alert system. Please try again.",
        variant: "destructive",
      });
    }
  };

  const systemControls = [
    {
      title: 'Emergency Shutdown',
      description: 'Immediately shut down all grid operations',
      icon: Power,
      variant: 'destructive' as const,
      onClick: handleEmergencyShutdown,
      testId: 'button-emergency-shutdown'
    },
    {
      title: 'Maintenance Mode',
      description: 'Enable maintenance mode for system updates',
      icon: Wrench,
      variant: 'default' as const,
      onClick: handleMaintenanceMode,
      testId: 'button-maintenance-mode'
    },
    {
      title: 'Alert System Test',
      description: 'Test buzzer and notification systems',
      icon: Bell,
      variant: 'default' as const,
      onClick: handleAlertSystemTest,
      testId: 'button-alert-test'
    }
  ];

  const activeSessions = [
    {
      type: 'Admin Console',
      user: 'You (Current)',
      icon: Monitor,
      status: 'active'
    },
    {
      type: 'Mobile App',
      user: 'Field Technician',
      icon: Smartphone,
      status: 'active'
    },
    {
      type: 'Monitoring Station',
      user: 'Operator #2',
      icon: Monitor,
      status: 'active'
    }
  ];

  const systemLogs = [
    {
      label: 'Last Login',
      value: new Date().toLocaleString('en-US', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        hour12: false
      }),
      status: null
    },
    {
      label: 'System Check',
      value: 'Completed',
      status: 'success'
    },
    {
      label: 'Last Alert',
      value: '2 hours ago',
      status: 'warning'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Grid Operator Management */}
      <Card className="shadow-sm" data-testid="card-grid-operators">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold flex items-center">
              <Phone className="mr-2 h-5 w-5" />
              Grid Operators Contact Management
            </CardTitle>
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button onClick={() => {
                  setEditingOperator(null);
                  setFormData({ name: '', phoneNumber: '', email: '', role: 'operator', zone: '', isActive: true });
                }} data-testid="button-add-operator">
                  <Plus className="mr-2 h-4 w-4" />
                  Add Operator
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                  <DialogTitle>{editingOperator ? 'Edit' : 'Add'} Grid Operator</DialogTitle>
                  <DialogDescription>
                    {editingOperator ? 'Update' : 'Add new'} grid operator contact information for emergency alerts.
                  </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleSubmitOperator} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Name</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="Enter operator name"
                      required
                      data-testid="input-operator-name"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phoneNumber">Phone Number</Label>
                    <Input
                      id="phoneNumber"
                      type="tel"
                      value={formData.phoneNumber}
                      onChange={(e) => setFormData({ ...formData, phoneNumber: e.target.value })}
                      placeholder="+1-555-123-4567"
                      required
                      data-testid="input-operator-phone"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email (optional)</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="operator@energy.com"
                      data-testid="input-operator-email"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="role">Role</Label>
                    <Select value={formData.role} onValueChange={(value: 'operator' | 'supervisor' | 'manager') => setFormData({ ...formData, role: value })}>
                      <SelectTrigger data-testid="select-operator-role">
                        <SelectValue placeholder="Select role" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="operator">Operator</SelectItem>
                        <SelectItem value="supervisor">Supervisor</SelectItem>
                        <SelectItem value="manager">Manager</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="zone">Coverage Zone (optional)</Label>
                    <Input
                      id="zone"
                      value={formData.zone}
                      onChange={(e) => setFormData({ ...formData, zone: e.target.value })}
                      placeholder="North District, Zone A, etc."
                      data-testid="input-operator-zone"
                    />
                  </div>
                  <div className="flex justify-end space-x-2">
                    <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button type="submit" data-testid="button-save-operator">
                      {editingOperator ? 'Update' : 'Add'} Operator
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="text-sm text-muted-foreground mb-4">
              Manage grid operator contacts for emergency alert notifications. Active operators will receive SMS alerts during critical events.
            </div>
            {gridOperators.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <UserCheck className="mx-auto h-12 w-12 mb-4 opacity-50" />
                <p>No grid operators added yet</p>
                <p className="text-sm">Add operators to enable emergency notifications</p>
              </div>
            ) : (
              <div className="space-y-3">
                {gridOperators.map((operator) => (
                  <div
                    key={operator.id}
                    className="flex items-center justify-between p-4 border border-border rounded-lg"
                    data-testid={`operator-${operator.id}`}
                  >
                    <div className="flex items-center space-x-3">
                      <div className={`w-3 h-3 rounded-full ${operator.isActive ? 'bg-secondary' : 'bg-muted'}`}></div>
                      <div>
                        <div className="font-medium text-card-foreground">{operator.name}</div>
                        <div className="text-sm text-muted-foreground flex items-center">
                          <Phone className="mr-1 h-3 w-3" />
                          {operator.phoneNumber}
                          {operator.zone && ` | ${operator.zone}`}
                        </div>
                        {operator.email && (
                          <div className="text-xs text-muted-foreground">{operator.email}</div>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge variant={operator.role === 'manager' ? 'default' : operator.role === 'supervisor' ? 'secondary' : 'outline'}>
                        {operator.role}
                      </Badge>
                      <Button
                        onClick={() => handleEditOperator(operator)}
                        variant="outline"
                        size="sm"
                        data-testid={`button-edit-operator-${operator.id}`}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        onClick={() => handleDeleteOperator(operator.id)}
                        variant="outline"
                        size="sm"
                        data-testid={`button-delete-operator-${operator.id}`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* System Controls */}
        <Card className="shadow-sm" data-testid="card-system-controls">
        <CardHeader>
          <CardTitle className="text-lg font-semibold flex items-center">
            <Shield className="mr-2 h-5 w-5" />
            System Controls
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {systemControls.map((control) => {
              const Icon = control.icon;
              return (
                <div
                  key={control.title}
                  className="flex items-center justify-between p-4 border border-border rounded-lg"
                >
                  <div>
                    <div className="font-medium text-card-foreground">{control.title}</div>
                    <div className="text-sm text-muted-foreground">{control.description}</div>
                  </div>
                  <Button
                    onClick={control.onClick}
                    variant={control.variant}
                    size="sm"
                    data-testid={control.testId}
                  >
                    <Icon className="mr-2 h-4 w-4" />
                    {control.title.split(' ')[0]}
                  </Button>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* User Management */}
      <Card className="shadow-sm" data-testid="card-user-management">
        <CardHeader>
          <CardTitle className="text-lg font-semibold flex items-center">
            <Users className="mr-2 h-5 w-5" />
            User Management
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Active Sessions */}
            <div className="p-4 border border-border rounded-lg">
              <div className="flex items-center justify-between mb-3">
                <span className="font-medium text-card-foreground">Active Sessions</span>
                <Badge variant="secondary" data-testid="badge-active-sessions">
                  {activeSessions.length}
                </Badge>
              </div>
              <div className="space-y-2 text-sm">
                {activeSessions.map((session, index) => {
                  const Icon = session.icon;
                  return (
                    <div key={index} className="flex justify-between items-center">
                      <div className="flex items-center text-muted-foreground">
                        <Icon className="mr-2 h-4 w-4" />
                        {session.type}
                      </div>
                      <span className="text-card-foreground">{session.user}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* System Logs */}
            <div className="p-4 border border-border rounded-lg">
              <div className="font-medium text-card-foreground mb-3">System Logs</div>
              <div className="space-y-2 text-sm">
                {systemLogs.map((log, index) => (
                  <div key={index} className="flex justify-between">
                    <span className="text-muted-foreground">{log.label}</span>
                    <span className={
                      log.status === 'success' ? 'text-secondary' :
                      log.status === 'warning' ? 'text-accent' :
                      'text-card-foreground'
                    }>
                      {log.value}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Current User Info */}
            {user && (
              <>
                <Separator />
                <div className="p-4 border border-border rounded-lg">
                  <div className="font-medium text-card-foreground mb-3">Current User</div>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Name</span>
                      <span className="text-card-foreground">
                        {user.firstName && user.lastName 
                          ? `${user.firstName} ${user.lastName}` 
                          : 'Administrator'}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Email</span>
                      <span className="text-card-foreground">{user.email || 'N/A'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Role</span>
                      <Badge variant="outline">Official</Badge>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        </CardContent>
      </Card>
      </div>
    </div>
  );
}
