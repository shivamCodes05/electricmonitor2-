import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Bell, AlertTriangle, CheckCircle, Clock } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { isUnauthorizedError } from '@/lib/authUtils';

interface SafetyAlert {
  id: string;
  type: 'warning' | 'critical' | 'normal';
  title: string;
  description?: string;
  location?: string;
  coordinates?: string;
  createdAt: string;
}

interface AlertPanelProps {
  onAlertStatusChange: (status: 'normal' | 'warning' | 'critical') => void;
}

export default function AlertPanel({ onAlertStatusChange }: AlertPanelProps) {
  const [alerts, setAlerts] = useState<SafetyAlert[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    fetchAlerts();
    
    // Setup WebSocket connection for real-time alert updates
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const hostname = window.location.hostname;
    const port = window.location.port || (window.location.protocol === "https:" ? "443" : "80");
    const wsUrl = `${protocol}//${hostname}:${port}/ws`;
    const socket = new WebSocket(wsUrl);

    socket.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data);
        if (message.type === 'emergency_sos' || message.type === 'test_alert') {
          fetchAlerts(); // Refresh alerts when new ones come in
          
          // Update parent component with alert status
          if (message.data?.type === 'critical') {
            onAlertStatusChange('critical');
          } else if (message.data?.type === 'warning') {
            onAlertStatusChange('warning');
          }
          
          // Show toast notification
          toast({
            title: "New Alert",
            description: message.data?.title || "A new safety alert has been triggered.",
            variant: message.data?.type === 'critical' ? 'destructive' : 'default',
          });
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };

    return () => {
      socket.close();
    };
  }, [onAlertStatusChange, toast]);

  const fetchAlerts = async () => {
    try {
      const response = await fetch('/api/alerts', { credentials: 'include' });
      if (response.ok) {
        const data = await response.json();
        setAlerts(data);
        
        // Determine overall alert status
        const hasCritical = data.some((alert: SafetyAlert) => alert.type === 'critical');
        const hasWarning = data.some((alert: SafetyAlert) => alert.type === 'warning');
        
        if (hasCritical) {
          onAlertStatusChange('critical');
        } else if (hasWarning) {
          onAlertStatusChange('warning');
        } else {
          onAlertStatusChange('normal');
        }
      }
    } catch (error: any) {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      console.error('Error fetching alerts:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSoundAlert = async () => {
    try {
      const response = await fetch('/api/system/test-alert', {
        method: 'POST',
        credentials: 'include',
      });

      if (response.ok) {
        toast({
          title: "Alert Test",
          description: "Alert system test initiated. All operators have been notified.",
        });
      }
    } catch (error: any) {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to sound alert. Please try again.",
        variant: "destructive",
      });
    }
  };

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'critical':
        return <AlertTriangle className="h-4 w-4" />;
      case 'warning':
        return <AlertTriangle className="h-4 w-4" />;
      default:
        return <CheckCircle className="h-4 w-4" />;
    }
  };

  const getAlertVariant = (type: string): "default" | "secondary" | "destructive" | "outline" => {
    switch (type) {
      case 'critical':
        return 'destructive';
      case 'warning':
        return 'default';
      default:
        return 'secondary';
    }
  };

  const getAlertBgColor = (type: string) => {
    switch (type) {
      case 'critical':
        return 'bg-destructive/10 border-destructive/20';
      case 'warning':
        return 'bg-accent/10 border-accent/20';
      default:
        return 'bg-secondary/10 border-secondary/20';
    }
  };

  const formatTimeAgo = (dateString: string) => {
    const now = new Date();
    const alertTime = new Date(dateString);
    const diffMs = now.getTime() - alertTime.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    
    if (diffMins < 1) return 'Just now';
    if (diffMins === 1) return '1 minute ago';
    if (diffMins < 60) return `${diffMins} minutes ago`;
    
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours === 1) return '1 hour ago';
    if (diffHours < 24) return `${diffHours} hours ago`;
    
    return alertTime.toLocaleDateString();
  };

  if (loading) {
    return (
      <Card className="shadow-sm">
        <CardContent className="p-6">
          <div className="flex items-center justify-center h-32">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-sm" data-testid="card-alert-panel">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">Active Alerts</CardTitle>
          <Button 
            onClick={handleSoundAlert}
            variant="destructive"
            size="sm"
            data-testid="button-sound-alert"
          >
            <Bell className="mr-2 h-4 w-4" />
            Sound Alert
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {alerts.length === 0 ? (
            <div className={`flex items-center justify-between p-4 bg-secondary/10 border border-secondary/20 rounded-lg`}>
              <div className="flex items-center">
                <div className="w-3 h-3 bg-secondary rounded-full mr-3"></div>
                <div>
                  <div className="font-medium text-card-foreground">All Systems Normal - Grid Operational</div>
                  <div className="text-sm text-muted-foreground">No active alerts</div>
                </div>
              </div>
              <Badge variant="secondary">NORMAL</Badge>
            </div>
          ) : (
            alerts.map((alert) => (
              <div
                key={alert.id}
                className={`flex items-center justify-between p-4 border rounded-lg ${getAlertBgColor(alert.type)}`}
                data-testid={`alert-${alert.id}`}
              >
                <div className="flex items-center">
                  <div className={`w-3 h-3 rounded-full mr-3 ${
                    alert.type === 'critical' ? 'bg-destructive animate-pulse' :
                    alert.type === 'warning' ? 'bg-accent animate-pulse' : 'bg-secondary'
                  }`}></div>
                  <div>
                    <div className="font-medium text-card-foreground">{alert.title}</div>
                    <div className="text-sm text-muted-foreground">
                      {alert.location && `${alert.location} | `}
                      <Clock className="inline h-3 w-3 mr-1" />
                      {formatTimeAgo(alert.createdAt)}
                    </div>
                    {alert.description && (
                      <div className="text-sm text-muted-foreground mt-1">{alert.description}</div>
                    )}
                  </div>
                </div>
                <Badge variant={getAlertVariant(alert.type)}>
                  {getAlertIcon(alert.type)}
                  <span className="ml-1">{alert.type.toUpperCase()}</span>
                </Badge>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}
