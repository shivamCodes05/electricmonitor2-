import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MapPin, Zap, Activity } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { isUnauthorizedError } from '@/lib/authUtils';

interface PowerLine {
  id: string;
  name: string;
  location: string;
  status: 'active' | 'caution' | 'fault';
  loadPercentage: number;
  lastCheck: string;
}

interface Pole {
  id: string;
  poleId: string;
  coordinates: string;
  status: 'stable' | 'inspection' | 'maintenance';
  lastInspection: string;
}

export default function LineStatus() {
  const [powerLines, setPowerLines] = useState<PowerLine[]>([]);
  const [poles, setPoles] = useState<Pole[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    fetchPowerLines();
    fetchPoles();
  }, []);

  const fetchPowerLines = async () => {
    try {
      const response = await fetch('/api/powerlines', { credentials: 'include' });
      if (response.ok) {
        const data = await response.json();
        setPowerLines(data);
      }
    } catch (error: any) {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      console.error('Error fetching power lines:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchPoles = async () => {
    try {
      const response = await fetch('/api/poles', { credentials: 'include' });
      if (response.ok) {
        const data = await response.json();
        setPoles(data);
      }
    } catch (error: any) {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      console.error('Error fetching poles:', error);
    }
  };

  const getLineStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-secondary';
      case 'caution':
        return 'bg-accent';
      case 'fault':
        return 'bg-destructive';
      default:
        return 'bg-secondary';
    }
  };

  const getLineStatusVariant = (status: string): "default" | "secondary" | "destructive" | "outline" => {
    switch (status) {
      case 'active':
        return 'secondary';
      case 'caution':
        return 'default';
      case 'fault':
        return 'destructive';
      default:
        return 'secondary';
    }
  };

  const getPoleStatusColor = (status: string) => {
    switch (status) {
      case 'stable':
        return 'text-secondary';
      case 'inspection':
        return 'text-accent';
      case 'maintenance':
        return 'text-destructive';
      default:
        return 'text-secondary';
    }
  };

  const getPoleStatusVariant = (status: string): "default" | "secondary" | "destructive" | "outline" => {
    switch (status) {
      case 'stable':
        return 'secondary';
      case 'inspection':
        return 'default';
      case 'maintenance':
        return 'destructive';
      default:
        return 'secondary';
    }
  };

  const formatTimeAgo = (dateString: string) => {
    const now = new Date();
    const checkTime = new Date(dateString);
    const diffMs = now.getTime() - checkTime.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    
    if (diffMins < 1) return 'Just now';
    if (diffMins === 1) return '1 minute ago';
    if (diffMins < 60) return `${diffMins} minutes ago`;
    
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours === 1) return '1 hour ago';
    if (diffHours < 24) return `${diffHours} hours ago`;
    
    return checkTime.toLocaleDateString();
  };

  if (loading) {
    return (
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-center h-32">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          </CardContent>
        </Card>
        <Card className="shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-center h-32">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Line Connection Status */}
      <Card className="shadow-sm" data-testid="card-line-status">
        <CardHeader>
          <CardTitle className="text-lg font-semibold">Line Connection Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {powerLines.length === 0 ? (
              <div className="text-center text-muted-foreground py-8">
                <Zap className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>No power line data available</p>
              </div>
            ) : (
              powerLines.map((line) => (
                <div
                  key={line.id}
                  className="flex items-center justify-between p-4 border border-border rounded-lg"
                  data-testid={`line-${line.id}`}
                >
                  <div className="flex items-center">
                    <div className={`w-4 h-4 ${getLineStatusColor(line.status)} rounded-full mr-3`}></div>
                    <div>
                      <div className="font-medium text-card-foreground" data-testid={`text-line-name-${line.id}`}>
                        {line.name}
                      </div>
                      <div className="text-sm text-muted-foreground" data-testid={`text-line-location-${line.id}`}>
                        {line.location}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge variant={getLineStatusVariant(line.status)}>
                      {line.status.toUpperCase()}
                    </Badge>
                    <div className="text-xs text-muted-foreground mt-1">
                      Load: {line.loadPercentage}%
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {formatTimeAgo(line.lastCheck)}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Pole Infrastructure Status */}
      <Card className="shadow-sm" data-testid="card-pole-status">
        <CardHeader>
          <CardTitle className="text-lg font-semibold">Pole Infrastructure</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {poles.length === 0 ? (
              <div className="text-center text-muted-foreground py-8">
                <Activity className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>No pole data available</p>
              </div>
            ) : (
              poles.map((pole) => (
                <div
                  key={pole.id}
                  className="flex items-center justify-between p-4 border border-border rounded-lg"
                  data-testid={`pole-${pole.id}`}
                >
                  <div className="flex items-center">
                    <MapPin className={`${getPoleStatusColor(pole.status)} mr-3 h-4 w-4`} />
                    <div>
                      <div className="font-medium text-card-foreground" data-testid={`text-pole-id-${pole.id}`}>
                        {pole.poleId}
                      </div>
                      <div className="text-sm text-muted-foreground" data-testid={`text-pole-coordinates-${pole.id}`}>
                        {pole.coordinates}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge variant={getPoleStatusVariant(pole.status)}>
                      {pole.status.toUpperCase()}
                    </Badge>
                    <div className="text-xs text-muted-foreground mt-1">
                      {formatTimeAgo(pole.lastInspection)}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
