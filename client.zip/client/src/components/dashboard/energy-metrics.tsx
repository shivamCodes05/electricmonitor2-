import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Sun, Battery, TrendingUp, Database, ArrowUp, CheckCircle } from 'lucide-react';

// Helper function to validate numeric values
const isValidNumeric = (v: any): boolean => 
  v !== null && v !== undefined && v !== '' && Number.isFinite(Number(v));

interface EnergyData {
  solarGeneration: string;
  batteryCharge: number;
  gridEfficiency: string;
  energyStored: string;
}

export default function EnergyMetrics() {
  const [energyData, setEnergyData] = useState<EnergyData>({
    solarGeneration: '24.7',
    batteryCharge: 87,
    gridEfficiency: '94.2',
    energyStored: '156.3'
  });

  useEffect(() => {
    // Fetch initial data
    const fetchEnergyData = async () => {
      try {
        const response = await fetch('/api/energy/latest', { credentials: 'include' });
        if (response.ok) {
          const data = await response.json();
          if (data) {
            setEnergyData({
              solarGeneration: (data.solarGeneration != null && data.solarGeneration !== '') ? data.solarGeneration : '24.7',
              batteryCharge: isValidNumeric(data.batteryCharge) ? Number(data.batteryCharge) : 87,
              gridEfficiency: (data.gridEfficiency != null && data.gridEfficiency !== '') ? data.gridEfficiency : '94.2',
              energyStored: (data.energyStored != null && data.energyStored !== '') ? data.energyStored : '156.3'
            });
          }
        }
      } catch (error) {
        console.error('Error fetching energy data:', error);
      }
    };

    fetchEnergyData();

    // Setup WebSocket connection for real-time updates
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const socket = new WebSocket(wsUrl);

    socket.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data);
        if (message.type === 'energy_update') {
          setEnergyData({
            solarGeneration: (message.data.solarGeneration != null && message.data.solarGeneration !== '') ? message.data.solarGeneration : '24.7',
            batteryCharge: isValidNumeric(message.data.batteryCharge) ? Number(message.data.batteryCharge) : 87,
            gridEfficiency: (message.data.gridEfficiency != null && message.data.gridEfficiency !== '') ? message.data.gridEfficiency : '94.2',
            energyStored: (message.data.energyStored != null && message.data.energyStored !== '') ? message.data.energyStored : '156.3'
          });
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };

    return () => {
      socket.close();
    };
  }, []);

  const metrics = [
    {
      title: 'Solar Generation',
      value: energyData.solarGeneration,
      unit: 'kW Generated',
      icon: Sun,
      iconColor: 'text-accent',
      bgColor: 'bg-accent/10',
      trend: '+12% from yesterday',
      trendIcon: ArrowUp,
      trendColor: 'text-secondary',
      testId: 'metric-solar-generation'
    },
    {
      title: 'Battery Status',
      value: energyData.batteryCharge.toString(),
      unit: '% Capacity',
      icon: Battery,
      iconColor: 'text-secondary',
      bgColor: 'bg-secondary/10',
      progress: energyData.batteryCharge,
      testId: 'metric-battery-status'
    },
    {
      title: 'Grid Efficiency',
      value: energyData.gridEfficiency,
      unit: '% Efficient',
      icon: TrendingUp,
      iconColor: 'text-primary',
      bgColor: 'bg-primary/10',
      trend: 'Optimal Range',
      trendIcon: CheckCircle,
      trendColor: 'text-secondary',
      testId: 'metric-grid-efficiency'
    },
    {
      title: 'Energy Storage',
      value: energyData.energyStored,
      unit: 'kWh Total',
      icon: Database,
      iconColor: 'text-accent',
      bgColor: 'bg-accent/10',
      trend: '+8.4 kWh today',
      trendIcon: ArrowUp,
      trendColor: 'text-primary',
      testId: 'metric-energy-storage'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {metrics.map((metric) => {
        const Icon = metric.icon;
        const TrendIcon = metric.trendIcon;
        
        return (
          <Card key={metric.title} className="shadow-sm" data-testid={metric.testId}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className={`w-12 h-12 ${metric.bgColor} rounded-lg flex items-center justify-center`}>
                  <Icon className={`${metric.iconColor} h-5 w-5`} />
                </div>
                <span className="text-sm text-muted-foreground">Current</span>
              </div>
              <div>
                <div className="text-3xl font-bold text-card-foreground" data-testid={`value-${metric.testId}`}>
                  {metric.value}
                </div>
                <div className="text-sm text-muted-foreground">{metric.unit}</div>
                
                {metric.progress !== undefined && (
                  <div className="mt-3">
                    <Progress value={metric.progress} className="h-2" />
                  </div>
                )}
                
                {metric.trend && TrendIcon && (
                  <div className={`text-sm ${metric.trendColor} mt-1 flex items-center`}>
                    <TrendIcon className="mr-1 h-3 w-3" />
                    {metric.trend}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
