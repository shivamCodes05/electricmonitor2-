import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';

interface ChartData {
  time: string;
  solar: number;
  grid: number;
}

export default function PowerChart() {
  const [chartData, setChartData] = useState<ChartData[]>([]);
  const [peakGeneration, setPeakGeneration] = useState({ value: '28.4', time: '12:30 PM' });

  useEffect(() => {
    // Generate sample data for the last 24 hours
    const generateSampleData = () => {
      const data: ChartData[] = [];
      const now = new Date();
      
      for (let i = 23; i >= 0; i--) {
        const time = new Date(now.getTime() - i * 60 * 60 * 1000);
        const hour = time.getHours();
        
        // Solar generation peaks during daylight hours
        let solarValue = 0;
        if (hour >= 6 && hour <= 18) {
          const peakHour = 12;
          const maxGeneration = 30;
          const distanceFromPeak = Math.abs(hour - peakHour);
          solarValue = Math.max(0, maxGeneration - (distanceFromPeak * 2.5) + (Math.random() * 3 - 1.5));
        }
        
        // Grid baseline with some variation
        const gridValue = 5 + Math.random() * 3;
        
        data.push({
          time: time.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true }),
          solar: Math.round(solarValue * 10) / 10,
          grid: Math.round(gridValue * 10) / 10
        });
      }
      
      return data;
    };

    setChartData(generateSampleData());

    // Fetch historical data
    const fetchHistoricalData = async () => {
      try {
        const response = await fetch('/api/energy/history/24', { credentials: 'include' });
        if (response.ok) {
          const data = await response.json();
          if (data && data.length > 0) {
            const formattedData = data.slice(-24).map((entry: any) => ({
              time: new Date(entry.timestamp).toLocaleTimeString('en-US', { 
                hour: '2-digit', 
                minute: '2-digit', 
                hour12: true 
              }),
              solar: parseFloat(entry.solarGeneration) || 0,
              grid: 5 + Math.random() * 3 // Mock grid data
            }));
            
            setChartData(formattedData);
            
            // Find peak generation
            const peak = data.reduce((max: any, entry: any) => {
              const generation = parseFloat(entry.solarGeneration) || 0;
              return generation > parseFloat(max.solarGeneration || 0) ? entry : max;
            }, data[0]);
            
            if (peak) {
              setPeakGeneration({
                value: parseFloat(peak.solarGeneration).toFixed(1),
                time: new Date(peak.timestamp).toLocaleTimeString('en-US', { 
                  hour: '2-digit', 
                  minute: '2-digit', 
                  hour12: true 
                })
              });
            }
          }
        }
      } catch (error) {
        console.error('Error fetching historical data:', error);
      }
    };

    fetchHistoricalData();
  }, []);

  return (
    <Card className="shadow-sm" data-testid="card-power-chart">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">Power Generation (24h)</CardTitle>
          <div className="flex items-center space-x-4 text-sm">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-primary rounded-full"></div>
              <span className="text-muted-foreground">Solar</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-secondary rounded-full"></div>
              <span className="text-muted-foreground">Grid</span>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
              <XAxis 
                dataKey="time" 
                className="text-xs text-muted-foreground"
                tick={{ fontSize: 12 }}
              />
              <YAxis 
                className="text-xs text-muted-foreground"
                tick={{ fontSize: 12 }}
                label={{ value: 'kW', angle: -90, position: 'insideLeft' }}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px'
                }}
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="solar" 
                stroke="hsl(var(--primary))" 
                strokeWidth={2}
                name="Solar Generation"
                dot={{ fill: 'hsl(var(--primary))', strokeWidth: 2, r: 4 }}
              />
              <Line 
                type="monotone" 
                dataKey="grid" 
                stroke="hsl(var(--secondary))" 
                strokeWidth={2}
                name="Grid Input"
                dot={{ fill: 'hsl(var(--secondary))', strokeWidth: 2, r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="text-center mt-4 text-sm text-muted-foreground">
          <span data-testid="text-peak-generation">
            Peak generation: {peakGeneration.value} kW at {peakGeneration.time}
          </span>
        </div>
      </CardContent>
    </Card>
  );
}
