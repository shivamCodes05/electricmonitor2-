import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';

interface ElectricalData {
  voltage: string;
  current: string;
  frequency: string;
}

export default function ElectricalGauges() {
  const [electricalData, setElectricalData] = useState<ElectricalData>({
    voltage: '240.2',
    current: '12.8',
    frequency: '50.1'
  });

  useEffect(() => {
    // Fetch initial data
    const fetchElectricalData = async () => {
      try {
        const response = await fetch('/api/energy/latest', { credentials: 'include' });
        if (response.ok) {
          const data = await response.json();
          if (data) {
            setElectricalData({
              voltage: (data.voltage != null && data.voltage !== '') ? data.voltage : '240.2',
              current: (data.current != null && data.current !== '') ? data.current : '12.8',
              frequency: (data.frequency != null && data.frequency !== '') ? data.frequency : '50.1'
            });
          }
        }
      } catch (error) {
        console.error('Error fetching electrical data:', error);
      }
    };

    fetchElectricalData();

    // Setup WebSocket connection for real-time updates
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const socket = new WebSocket(wsUrl);

    socket.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data);
        if (message.type === 'energy_update') {
          setElectricalData({
            voltage: (message.data.voltage != null && message.data.voltage !== '') ? message.data.voltage : '240.2',
            current: (message.data.current != null && message.data.current !== '') ? message.data.current : '12.8',
            frequency: (message.data.frequency != null && message.data.frequency !== '') ? message.data.frequency : '50.1'
          });
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };

    return () => {
      socket.close();
    };
  }, []);

  const getVoltageProgress = (voltage: string) => {
    const val = parseFloat(voltage);
    // Normal range is 220V - 250V, so we map this to 0-100%
    return Math.min(Math.max(((val - 220) / (250 - 220)) * 100, 0), 100);
  };

  const getCurrentProgress = (current: string) => {
    const val = parseFloat(current);
    // Normal range is 0A - 20A
    return Math.min(Math.max((val / 20) * 100, 0), 100);
  };

  const getFrequencyProgress = (frequency: string) => {
    const val = parseFloat(frequency);
    // Normal range is 49Hz - 51Hz, centered at 50Hz
    return Math.min(Math.max(((val - 49) / (51 - 49)) * 100, 0), 100);
  };

  const gauges = [
    {
      label: 'Voltage (V)',
      value: electricalData.voltage,
      progress: getVoltageProgress(electricalData.voltage),
      color: 'bg-primary',
      range: { min: '220V', max: '250V' },
      testId: 'gauge-voltage'
    },
    {
      label: 'Current (A)',
      value: electricalData.current,
      progress: getCurrentProgress(electricalData.current),
      color: 'bg-secondary',
      range: { min: '0A', max: '20A' },
      testId: 'gauge-current'
    },
    {
      label: 'Frequency (Hz)',
      value: electricalData.frequency,
      progress: getFrequencyProgress(electricalData.frequency),
      color: 'bg-accent',
      range: { min: '49Hz', max: '51Hz' },
      testId: 'gauge-frequency'
    }
  ];

  return (
    <Card className="shadow-sm" data-testid="card-electrical-gauges">
      <CardHeader>
        <CardTitle className="text-lg font-semibold">Live Electrical Metrics</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {gauges.map((gauge) => (
            <div key={gauge.label} className="flex items-center justify-between" data-testid={gauge.testId}>
              <div className="flex-1">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-card-foreground">{gauge.label}</span>
                  <span className="text-lg font-bold text-primary" data-testid={`value-${gauge.testId}`}>
                    {gauge.value}
                  </span>
                </div>
                <div className="w-full bg-muted rounded-full h-3">
                  <div 
                    className={`${gauge.color} h-3 rounded-full transition-all duration-500 ease-in-out`}
                    style={{ width: `${gauge.progress}%` }}
                  ></div>
                </div>
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>{gauge.range.min}</span>
                  <span>{gauge.range.max}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
