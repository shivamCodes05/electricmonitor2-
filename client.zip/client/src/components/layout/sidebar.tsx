import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Zap, BarChart3, Shield, CloudSun, Settings, LogOut, Menu } from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export default function Sidebar({ activeTab, onTabChange }: SidebarProps) {
  const [isOpen, setIsOpen] = useState(false);
  
  const handleLogout = () => {
    window.location.href = "/api/logout";
  };
  
  const handleTabChange = (tab: string) => {
    onTabChange(tab);
    setIsOpen(false); // Close mobile menu after selection
  };

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
    { id: 'safety', label: 'Safety Monitoring', icon: Shield },
    { id: 'weather', label: 'Weather & Location', icon: CloudSun },
    { id: 'admin', label: 'Admin Controls', icon: Settings },
  ];

  const SidebarContent = () => (
    <>
      <div className="flex items-center justify-center h-16 border-b border-border">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <Zap className="text-primary-foreground h-5 w-5" />
          </div>
          <span className="text-xl font-bold text-card-foreground">Energy Monitor</span>
        </div>
      </div>
      
      <nav className="mt-8">
        <div className="px-4 space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            
            return (
              <Button
                key={item.id}
                onClick={() => handleTabChange(item.id)}
                variant={isActive ? 'default' : 'ghost'}
                className={`w-full justify-start h-12 ${
                  isActive 
                    ? 'bg-primary text-primary-foreground' 
                    : 'text-muted-foreground hover:text-card-foreground hover:bg-muted'
                }`}
                data-testid={`nav-${item.id}`}
              >
                <Icon className="mr-3 h-4 w-4" />
                {item.label}
              </Button>
            );
          })}
        </div>
        
        <div className="mt-8 px-4">
          <Separator className="mb-4" />
          <Button
            onClick={handleLogout}
            variant="ghost"
            className="w-full justify-start h-12 text-muted-foreground hover:text-card-foreground"
            data-testid="button-logout"
          >
            <LogOut className="mr-3 h-4 w-4" />
            Logout
          </Button>
        </div>
      </nav>
    </>
  );

  return (
    <>
      {/* Mobile Menu Button */}
      <div className="md:hidden fixed top-4 left-4 z-50">
        <Sheet open={isOpen} onOpenChange={setIsOpen}>
          <SheetTrigger asChild>
            <Button variant="outline" size="icon" data-testid="button-mobile-menu">
              <Menu className="h-4 w-4" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-64 p-0">
            <SidebarContent />
          </SheetContent>
        </Sheet>
      </div>

      {/* Desktop Sidebar */}
      <aside className="hidden md:flex fixed inset-y-0 left-0 w-64 bg-card border-r border-border flex-col z-30">
        <SidebarContent />
      </aside>
    </>
  );
}
